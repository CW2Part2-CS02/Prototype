<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Request
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Home2.php">Data</a></li>
        <li ><a href="Events.php">Events</a></li>
	    <li><a href="Notification.php">Notification</a></li>
        <li class="active"><a href="Request.php">Requests</a></li>
        <li><a href="Complains.php">Complaints</a></li>
        <li><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>

<div class="button"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;">
<div class="container">
  <h2 style="color:white;">Order Requests</h2>
       <?php
       $sql ="SELECT * FROM `user_orders` WHERE price='Pending'" ;
     $result = $conn->query($sql);


     if ($result->num_rows > 0) {

     while($row = $result->fetch_assoc()) {
         $name=$row['Name'];
         $street=$row['streetno'];
         $houseno=$row['Houseno'];
         $city=$row['city'];
         echo "
         <div class='panel-group'>
           <div class='panel panel-default'>
             <div class='panel-heading'><span style='font-weight:bold;'>UserName:</span><p>$name<p></div>
             <div class='panel-body'>
             <p><span style='font-weight:bold;'>House No:</span></p>
             <p><span>U<span>$houseno</p>
             <p><span style='font-weight:bold;'>Street No:</span></p>
             <p>$street</p>
             <p><span style='font-weight:bold;'>City:</span></p>
             <p>$city</p>
          </div>
          <div class='panel-footer'><div class='btn-group'>
          <form action='reqestacp.php' method='POST'>
          	<input type='hidden' name='Name' value=".$name.">
            <input type='hidden' name='streetno' value=".$street.">
            <input type='hidden' name='Houseno' value=".$houseno.">
            <input type='hidden' name='city' value=".$city.">
           <input type='submit' name='accept' value='Accept' class='btn btn-primary'>
         </div>
         <div class='btn-group'>
           <input type='submit' name='reject' value='Reject' class='btn btn-danger'>
           <form>

         </div></div>
           </div>
         <br>

         ";

     }
   }


        ?>

  </div>
</div>



</body>


</html>
