<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['ok'])){
$date=$_POST['date'];
$price=$_POST['price'];
$name=$_POST['Name'];
$street=$_POST['streetno'];
$houseno=$_POST['Houseno'];
$city=$_POST['city'];
$p=".";
if(!empty($date) && !empty($price)){
$query="UPDATE `user_orders` SET `data`='$date',`price`='$price',`paydtails`='$p' WHERE Name='$name' AND Houseno='$houseno'";
$run=$conn->query($query);
  echo "<script>alert('Order Updated Succesfuly')</script>";
header("location:Request.php");
}
else {
  echo "<script>alert('Enter Valid Input')</script>";
  header("location:Request.php");
}
}
if(isset($_POST['reject'])){
$name=$_POST['Name'];
$street=$_POST['streetno'];
$houseno=$_POST['Houseno'];
$city=$_POST['city'];
$dlt="DELETE FROM `user_orders` WHERE Name='$name' AND Houseno='$houseno'";
$queryrun=$conn->query($dlt);
if($queryrun){
header("location:Request.php");
}
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Request
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Home2.php">Data</a></li>
        <li ><a href="Events.php">Events</a></li>
	    <li><a href="Notification.php">Notification</a></li>
        <li class="active"><a href="Request.php">Requests</a></li>
        <li><a href="Complains.php">Complaints</a></li>
        <li><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>

<div class="button"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;">
<div class="container">
  <h2 style="color:white;">Maintain Order</h2>
       <?php




        if(isset($_POST['accept'])){
         $name=$_POST['Name'];
         $street=$_POST['streetno'];
         $houseno=$_POST['Houseno'];
         $city=$_POST['city'];
         echo "
         <div class='panel-group'>
           <div class='panel panel-default'>
             <div class='panel-heading'><span style='font-weight:bold;'>UserName:</span><p>$name<p></div>
             <div class='panel-body'>
             <p><span style='font-weight:bold;'>House No:</span></p>
             <p><span>U<span>$houseno</p>
             <p><span style='font-weight:bold;'>Street No:</span></p>
             <p>$street</p>
             <p><span style='font-weight:bold;'>City:</span></p>
             <p>$city</p>
             <h3>Enter Further Deatails</h3><br>
             <form action='' method='POST'>
             <input type='hidden' name='Name' value=".$name.">
              <input type='hidden' name='streetno' value=".$street.">
              <input type='hidden' name='Houseno' value=".$houseno.">
              <input type='hidden' name='city' value=".$city.">
             <div class='form-group'>
             	<label  control-label' style='float:left'>Price</label>
               <div class='col-md-4 inputGroupContainer'>
               <div class='input-group'>
               <input  name='price'  placeholder='Enter Price' class='form-control'  type='text'>
               </div>
               </div>
               <label  control-label' style='float:left'>Enter Date</label>
                <div class='col-md-4 inputGroupContainer'>
                <div class='input-group'>
                <input  name='date'  placeholder='Enter Date' class='form-control'  type='text'>
                 </div>
               </div>
             </div>
          </div>

          <div class='panel-footer'><div class='btn-group'>



           <input type='submit' style='margin-left:500px' name='ok' value='Submit' class='btn btn-success'>
         </div>
         <div class='btn-group'>

           <form>
         </div></div>
           </div>


         ";

     }


        ?>

  </div>
</div>



</body>


</html>
