<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Online user
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Home2.php">Data</a></li>
        <li ><a href="Events.php">Events</a></li>
	    <li><a href="Notification.php">Notification</a></li>
        <li><a href="Request.php">Requests</a></li>
        <li ><a href="Complains.php">Complaints</a></li>
        <li class="active"><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>

<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-50px;height:591px;padding-top:40px;">
<div class="button text-center">
   <div style="height:350px;width:650px;margin-left:425px;">
	 <img src="images/gate.png" style="width:100px;height:100px;margin-left:-200px;"></img>
	 <br>
   <legend style="color:white;margin-left:-100px;">Online Users</legend>
   <?php
   $sql ="SELECT * FROM `online`" ;
$result = $conn->query($sql);

if ($result->num_rows > 0) {

 while($row = $result->fetch_assoc()) {
        $u=$row['username'];
        echo"<table class='table table-striped' style='margin-left:-100px;'>
       <tr>
       <td>".$u."</td>
       <td>
        <form action='sendmessage.php' method='POST'>
        <input type='hidden' name='Name' value=".$u.">
             <input type='submit' name='msg' value='Message' style='margin-left:400px;'  class='btn btn-warning btn-xs'></td>

         </form></table>";


 }


}
else {
  echo "<p style='float:left;color:white;margin-left:-100px;'>No One is Currently online</p>";
}
    ?>
     <legend style="color:white;margin-left:-100px;"> Users</legend>
     <?php
     $sql ="SELECT * FROM `users`" ;
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {

   while($row = $result->fetch_assoc()) {
          $u=$row['fname'];
          echo"<table class='table table-striped' style='margin-left:-100px;'>
         <tr>
         <td>".$u."</td>
         <td>
          <form action='sendmessage.php' method='POST'>
          <input type='hidden' name='Name' value=".$u.">
               <input type='submit' name='msg' value='Message' style='margin-left:400px;'  class='btn btn-warning btn-xs'></td>

           </form></table>";


   }


  }
  else {
    echo "<p style='float:left;color:white;margin-left:-100px;'>No One is Currently online</p>";
  }
      ?>

 </div>
 </div>
 </div>



</body>


</html>
