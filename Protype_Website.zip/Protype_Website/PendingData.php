<!DOCTYPE html>
<html>
<head>
<title>
Pending Data
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }



  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
       <li class="active"><a href="Home2.php">Data</a></li>
       <li ><a href="Events.php">Events</a></li>
	   <li><a href="Notification.php">Notification</a></li>
       <li><a href="Request.php">Requests</a></li>
       <li><a href="Complains.php">Complaints</a></li>
       <li><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;padding-top:40px;">
<div class="container text-center">

<table class="table table-hover" style="color:white;">
<legend style="color:white;">All Pending Data</legend>
    <thead>
      <tr>
        <th>House No</th>
        <th>Street No</th>
        <th>Date</th>
		<th>Account Condition</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td></td>
        <td></td>
        <td></td>
		<td></td>
      </tr>
    </tbody>
  </table>

</div>
</div>
</body>


</html>
