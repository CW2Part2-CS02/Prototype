<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['Send'])) {
 $uname=$_POST['Name'];
 $message=$_POST['content'];
 if(!empty($message)){
   $sql="INSERT INTO `messages`(`username`, `content`) VALUES ('$uname','$message')";
   $res=$conn->query($sql);
   if($res){
       header("location:Online.php");
   }
 }
 else{

 }
}



 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Online user
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Home2.php">Data</a></li>
        <li ><a href="Events.php">Events</a></li>
	    <li><a href="Notification.php">Notification</a></li>
        <li><a href="Request.php">Requests</a></li>
        <li ><a href="Complains.php">Complaints</a></li>
        <li class="active"><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>

<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-50px;height:591px;padding-top:40px;">
<div class="button text-center">
   <div style="height:350px;width:650px;margin-left:425px;">
	 <img src="images/gate.png" style="width:100px;height:100px;margin-left:-200px;"></img>
	 <br>
   <legend style="color:white;margin-left:-100px;">Send Message</legend>
   <?php
   if (isset($_POST['msg'])) {
     $recvr=$_POST['Name'];


   echo "<form method='POST' action='sendmessage.php' role='form'>
     <div class='form-group'>
       <h2><span class='label label-primary' style='float:left;margin-left:-100px'>$recvr</span></h2>
       <input type='hidden' name='Name' value=".$recvr."><br><br>
       <textarea style='margin-left:-100px;' name='content' placeholder='Type Your Message Here' class='form-control' rows='3' id='comment'></textarea><br>
       <input type='submit' value='Send' name='Send' class='btn btn-success' style='margin-left:-190px'>
     </div>
   </form>
";
function show(){
  echo "<div class='alert alert-success'>
    <strong>Success!</strong> This alert box could indicate a successful or positive action.
  </div>";
}
}
    ?>


 </div>
 </div>
 </div>



</body>


</html>
