<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
<title>
Search Data
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }



  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
       <li class="active"><a href="Home2.php">Data</a></li>
       <li ><a href="Events.php">Events</a></li>
	   <li><a href="Notification.php">Notification</a></li>
       <li><a href="Request.php">Requests</a></li>
       <li><a href="Complains.php">Complaints</a></li>
       <li><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>
<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;padding-top:40px;">
<div class="container ">
<form class="well form-horizontal" action=" " method="post"  id="contact_form">
<fieldset>
<legend>Search User</legend>

<!-- password-->
<div class="form-group">
	<label class="col-md-4 control-label">Name</label>
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <input  name="Name" placeholder="Name" class="form-control"  type="text">
    </div>
  </div>
</div>


<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <button type="submit" name="submit" class="btn btn-warning" >Search <span class="glyphicon glyphicon-send"></span></button>

  </div>
</div>



</fieldset>
</form>
</div>

<div class="container">

<table class="table table-hover"style="color:white;">
  <?php

    echo "<table class='table table-hover' style='color:white;'>
  <thead>
    <tr>
    <th>Name</th>
      <th>House No</th>
      <th>Street No</th>
        <th>City</th>
  <th>Price</th>
  <th>Date</th>
  <th>Account Condition</th>
    </tr>
  </thead>";
  if(isset($_POST['submit'])){
  $name=$_POST['Name'];

  $sql ="SELECT * FROM `user_orders` WHERE Name='$name'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

while($row = $result->fetch_assoc()) {
  $name=$row['Name'];
  $houseno=$row['Houseno'];
  $streetno=$row['streetno'];
  $city=$row['city'];
  $price=$row['price'];
  $date=$row['data'];
  $condition=$row['paydtails'];
  echo "  <tbody>
      <tr>
        <td>".$name."</td>
        <td>".$houseno."</td>
        <td>".$streetno."</td>
   <td>".$city."</td>
   <td>".$price."</td>
   <td>".$date."</td>
    <td>".$condition."</td>
      </tr>";
}
}
echo "  </tbody></table>";
}


   ?>

</div>
</div>
</body>


</html>
