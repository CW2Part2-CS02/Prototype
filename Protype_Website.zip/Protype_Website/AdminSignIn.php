<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['submit'])) {
$username= $_POST['username'];
$password= $_POST['password'];
if(!empty($username) && !empty($password)){
  $sql = "SELECT * FROM admin WHERE username='$username' AND pwd='$password'";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
         $_SESSION['username']=$username;
         header("location:Home2.php");
  }
  else {
     echo "<h1 style='color:white'>Wrong Password</h1>";
 }
}
 else {
    echo "<h1 style='color:white'>Wrong Password</h1>";
}
}
// require_once("connection.inc.php");
// if (isset($_POST['submit'])) {
// $username= $_POST['username'];
// $password= $_POST['password'];
// if(!empty($username) && !empty($password)){
//   $sql ="SELECT * FROM admin WHERE username='$username' AND password='$password'";
//   $query_run=@mysql_query($sql);
//   while(mysql_fetch_assoc($query_run)){
//
//
//   }
//       // output data of each row
//
// }
// else {
// echo "<h1 style='color:white'>Wrong Password</h1>";
// }
// }
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Admin SignIn
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
#success_message{ display: none;}
body{
        background-image: url("images/9.jpg");

}



</style>
<body>
  <div class="row" style="background-color:black;height:100px;text-align:center">
    <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;margin-top:-50px;"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
  </div>

<div class="container text-center" >
<br><br>	
 <div class="container" style="background-color:black;width:400px;margin-bottom:50px;padding-bottom:100px;padding-top:50px;opacity:0.5;border-radius:50px">
 <div>
 <img src="images/gate.png" style="width:100px;height:100px;margin-top:-30px;"></img>

<form action="AdminSignIn.php" method="post"  id="contact_form"  >
<fieldset>
<legend style="color:white;padding-left:90px;">Admin SignIn!</legend>
<!--password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  placeholder="Username" name="username" class="form-control" style="border-radius:10px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--retype password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="password" placeholder="Password" class="form-control" style="border-radius:10px;"  type="password">
    </div>
  </div>
</div>
<!--rememberme-->
<div class="form-group"  >

    <div class="col-sm-offset-3 col-sm-6">
    <div class="checkbox" style="margin-left:-50px;">
    <label>
    <input type="checkbox" name="remembering" style="color:white;"/><span style="color:white;"> Remember me </span></label>
    </div>

    </div>
    </div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-3 control-label"></label>
  <div class="col-md-4"style="margin-left:75px;">
    <input type="submit" name="submit" class="btn btn-warning" value="Submit" ></input>
   <br>
  </div>
</div>

<!-- Forgot password-->
<div class="form-group"style="margin-left:-270px;margin-top:20px;">
	<label class="col-sm-offset-3 col-sm-10 "><a href="forgotPas.php"><span style="color:white;text-style:none;">Forgot Password</span></a></label>
</div>

</fieldset>
</form>
</div>
</div>
</div>



</body>

</html>
