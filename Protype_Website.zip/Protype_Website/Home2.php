<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Home
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
.{
margin:0px;
padding:0px;

}
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
	   <li class="active"><a href="Home2.php">Data</a></li>
       <li ><a href="Events.php">Events</a></li>
	   <li><a href="Notification.php">Notification</a></li>
       <li><a href="Request.php">Requests</a></li>
       <li><a href="Complains.php">Complaints</a></li>
       <li><a href="Online.php">Online</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
         <form  method="post" action="logout.php">
           <input type="submit"  value="Logout" name="logout">
         </form>

      </ul>
    </div>
  </div>
</nav>
 <div class="button text-center"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;">



    <div style="height:350px;width:350px;margin-left:500px;">
	 <img src="images/gate.png" style="width:100px;height:100px;"></img>
	 <br>
     <legend style="color:black;">Customers Data</legend>
       <button type="button" class="btn btn-info btn-lg"><a href="all.php" style="text-decoration:none;color:white;width:100px;">All Customers Data</a></button><br><br>
       <button type="button" class="btn btn-info btn-lg"><a href="paid.php" style="text-decoration:none;color:white;width:100px;">Pending Data</a></button><br><br>
	   <button type="button" class="btn btn-info btn-lg"><a href="Searchdata.php" style="text-decoration:none;color:white;width:100px;">Search Data</a></button><br><br>
    </div>

</div>
</body>


</html>
