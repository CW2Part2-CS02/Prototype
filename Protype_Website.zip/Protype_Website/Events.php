<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Event
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 100px;
      border-radius: 0;
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav">
    <li ><a href="Home2.php">Data</a></li>
    <li class="active"><a href="Events.php">Events</a></li>
	<li><a href="Notification.php">Notification</a></li>
    <li><a href="Request.php">Requests</a></li>
    <li><a href="Complains.php">Complaints</a></li>
    <li><a href="Online.php">Online</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <form  method="post" action="logout.php">
        <input type="submit"  value="Logout" name="logout">
      </form>
    </ul>
    </div>
  </div>
</nav>
<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-100px;height:391px;padding-top:40px;">
<div class="container text-center">
  <table class="table table-bordered"style="background-color:white;" >
  <tr class="danger">
        <td colspan="7">April 2017</td>
        </tr>
      <tr class="success  text-center">

        <td>S</td>
        <td>M</td>
        <td>T</td>
		<td>W</td>
        <td>T</td>
        <td>F</td>
		 <td>S</td>
      </tr>
      <tr>
        <td>28</td>
        <td>29</td>
        <td>30</td>
		<td>31</td>
        <td>1</td>
        <td>2</td>
		<td>3</td>
      </tr>
      <tr>
        <td>4</td>
        <td>5</td>
        <td style="background-color:red;">6</td>
		<td>7</td>
        <td>8</td>
        <td>9</td>
		<td>10</td>
      </tr>
      <tr>
        <td style="background-color:red;">11</td>
        <td>12</td>
        <td>13</td>
		<td>14</td>
        <td>15</td>
        <td  style="background-color:red;" >16</td>
		<td>17</td>
      </tr>
	  <tr>
        <td>18</td>
        <td>19</td>
        <td>20</td>
		<td>21</td>
        <td>22</td>
        <td>23</td>
		<td>24</td>
      </tr>
	  <tr>
        <td>25</td>
        <td>26</td>
        <td>27</td>
		<td style="background-color:red;">28</td>
        <td>29</td>
        <td>30</td>
		<td>1</td>
      </tr>
  </table>
  <p style="background-color:grey;">*Red part shows the days when we are not free..So we will not be available on these days.</p>
</div>

</div>

</body>


</html>
