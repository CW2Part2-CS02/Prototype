<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
if (isset($_POST['submit'])) {
$user=$_SESSION['username'];
$complain=$_POST['complain'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(!empty($complain)){
  $sql = "INSERT INTO `user_comp`( `username`, `complaim`) VALUES ('$username','$complain')";
  $result = mysqli_query($conn, $sql);
  if($result){

       echo "<script>alert('Your Complain has been submitted')</script>";
}

}

}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Client Complaints
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Payment.php">Payments</a></li>
        <li ><a href="schedule.php">Schedule</a></li>
	    <li><a href="order.php">Orders</a></li>
        <li class="active"><a href="clientComplain.php">Complaints</a></li>
         <li><a href="messagesuser.php">Messages</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>
<div class="cover"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;padding-top:40px;">
<div class="container">
 <form class="well form-horizontal" style="width:500px;margin-left:300px;" action=" " method="post"  id="contact_form" >
<fieldset>
<legend>Any Complaint </legend>
<div class="container">

  <form role="form" action="clientComplain.php" method="post">
    <div class="form-group">
     <div class="col-md-9">
    <textarea class="form-control" name="complain" style="width:400px;" rows="5" id="comment"></textarea><br>
    <input type="submit" name="submit" class="btn btn-warning" value="Submit" style="margin-left:160px;" ></input>
    </div>
  </form>
</div>
<!-- Button -->
<div class="form-group">
  <div class="col-md-4">

</div>
</div>
</fieldset>
</form>
</div>
        </div>

</body>


</html>
