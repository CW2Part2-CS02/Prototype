<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['submit'])) {
$username= $_POST['username'];
$password= $_POST['password'];
if(!empty($username) && !empty($password)){
  $sql = "SELECT * FROM users WHERE fname='$username' AND pwd='$password'";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
         $_SESSION['username']=$username;
         $sq="INSERT INTO `online`(`username`) VALUES ('$username')";
           $result = mysqli_query($conn, $sq);
         header("location:Payment.php");
  }
  else {
     echo "<h1 style='color:white'>Wrong Password</h1>";
 }
}
 else {
    echo "<h1 style='color:white'>Wrong Password</h1>";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>
Client sign in
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
#success_message{ display: none;}
body{
    background-image: url("images/9.jpg");

}
html{
  background-image: url(images/9.jpg);
}


</style>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">

    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
       <li><a href="StartPage.php">Home</a></li>
      </ul>
            </div>

        </div>
  </nav>
  <div class="container text-center" >
  <br><br>	
 <div class="container" style="background-color:black;width:400px;margin-bottom:50px;padding-bottom:100px;padding-top:50px;opacity:0.5;border-radius:50px">
 <div>
 <img src="images/gate.png" style="width:100px;height:100px;margin-top:-30px;"></img>
<form action="ClientSignIn.php" method="post"  >
<fieldset>
<legend style="color:white;padding-left:120px;">Client SignIn!</legend>
<!--password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="username" placeholder="Username" class="form-control" style="border-radius:10px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--retype password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="password" placeholder="Password" class="form-control" style="border-radius:10px;"  type="password">
    </div>
  </div>
</div>
<!--rememberme-->
<div class="form-group"  >

    <div class="col-sm-offset-3 col-sm-10">
    <div class="checkbox"style="margin-left:-180px;" >
    <label>
    <input type="checkbox" name="remembering" style="color:white;"/><span style="color:white;"> Remember me </span></label>
    </div>

    </div>
    </div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-3 control-label"></label>
  <div class="col-md-4"style="margin-left:-20px;">
    <input type="submit" name="submit" class="btn btn-warning" value="Submit" ></input>
   <br>
  </div>
</div>
<!-- Forgot password-->
<div class="form-group"style="margin-left:-270px;margin-top:20px;">
	<label class="col-sm-offset-3 col-sm-10 "><a href="forgotPas.php"><span style="color:white;text-style:none;">Forgot Password</span></a></label>
</div>
<div class="form-group" style="margin-left:-90px;">
	<label class="col-sm-offset-3 col-sm-10 "><a href="SignUp.php"><span style="color:white;text-style:none;">Not a member yet? Sign Up Now For Free.</span></a></label>
</div>

</fieldset>
</form>
</div>
</div>
</div>


</body>
</html>
