<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['submit'])) {
  $firstname= $_POST['first_name'];
  $lastname= $_POST['last_name'];
  $pwd= $_POST['password'];
  $cpwd= $_POST['cpassword'];
  $email= $_POST['email'];
  $phnum= $_POST['phone'];
  $housenum= $_POST['Housenam'];
  $city= $_POST['cityname'];
  $street= $_POST['streetnum'];
  $zip= $_POST['zipcode'];


  if(!empty($firstname) && !empty($lastname) && !empty($pwd) && !empty($cpwd) && !empty($email) && !empty($phnum) && !empty($housenum) && !empty($city) && !empty($street) && !empty($zip) ){
         if($pwd!=$cpwd){
             echo "<h1 style='color:white'>Password Don't Matches</h1>";
         }
     else{
       $sql = "INSERT INTO `users`(`fname`,`pwd`, `lname`, `email`, `phnum`, `husnum`, `city`, `street`, `zipcode`)
       VALUES ('$firstname','$pwd','$lastname','$email','$phnum','$housenum','$city','$street','$zip')";
       $result = mysqli_query($conn, $sql);
       if($result){
         $_SESSION['username']=$firstname;
         header("location:Payment.php");
     }
    }
  }
  else {
      echo "<h1 style='color:white'>Enter valid  Input</h1>";
  }
}




 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Sign Up
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
#success_message{ display: none;}
body{
       background-image: url("images/9.jpg");

}
html{
  background-image: url(images/9.jpg);
}

html{
  background-image: url(images/9.jpg);
}

</style>
<body>
  <div class="row" style="background-color:black;height:100px;text-align:center">
    <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;margin-top:-50px;"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
  </div>

  <div style="height:350px;width:350px;margin-left:500px;">
	 <img src="images/gate.png" style="width:100px;height:100px;margin-left:110px;"></img>
     <br>

<form action="" method="post"  id="contact_form"  >
<fieldset>
<legend style="color:white;padding-left:90px;">Sign Up Now!</legend>
<!--First Name-->
<div class="form-group" >

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="first_name" placeholder="First Name" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--Last Name-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="last_name" placeholder="Last Name" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--Email-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="email" placeholder="Email" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--Phone Nbr-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="phone" placeholder="Phone Number" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--House Number-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="Housenam" placeholder="House Number" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--City-->
<div class="form-group">
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="cityname" placeholder="City Name" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--Street-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="streetnum" placeholder="Street Number" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<!--Zip code-->
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="zipcode" placeholder="Zip Code" class="form-control" style="border-radius:10px;margin-left:30px;"  type="text">
    </div>
  </div>
</div><br><br>
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">
<input  name="password" placeholder="Password" class="form-control" style="border-radius:10px;margin-left:30px;" style="border-radius:10px;"  type="password">

    </div>
  </div>
</div><br><br>
<div class="form-group" >
  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">
<input  name="cpassword" placeholder="Confirm Password" class="form-control" style="border-radius:10px;margin-left:30px;" style="border-radius:10px;"  type="password">

    </div>
  </div>
</div><br><br>
<!-- -->
<div class="form-group">
  <label class="col-md-3 control-label"></label>
  <div class="col-md-4">
    <input type="submit" name="submit"  value="SingUp" class="btn btn-warning" ></input
   <br>
  </div>
</div>
<!----->



</body>
</html>
