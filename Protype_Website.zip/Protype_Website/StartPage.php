<html>
<head>
<title>
Start page
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
<style>
body{
    background-image: url("images/9.jpg");
background-repeat:no-repeat;
background-size:100%;
}
html{
  background-image: url(images/9.jpg);
}

#service1{

}
body { margin: 0; }
div#slider { overflow: hidden; border:4px solid black;margin-top: 0px;}
div#slider figure img { width: 20%; float: left;height: 500px;}
div#slider figure {
  position: relative;
  width: 500%;
  margin: 0;
  left: 0;
  text-align: left;
  font-size: 0;
  animation: 10s slidy infinite;
}
</style>
</head>
<body>
<div class="row" style="background-color:black;height:100px;text-align:center">
  <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;margin-top:-50px;"></div>
  <div class="col-sm-4"></div>
  <div class="col-sm-4"></div>
</div>
  <div class="container text-center" >


 <br><br>
 <div class="container" style="background-color:black;width:400px;margin-bottom:50px;margin-top:10px;padding-bottom:100px;padding-top:50px;opacity:0.5;border-radius:50px">



    <div>
	 <img src="images/gate.png" style="width:100px;height:100px;margin-top:-30px;"></img>
     <br>
       <a  href="AdminSignIn.php"><input type="button" name="admin" class="btn btn-info" value="Admin" style="width:160px; margin-bottom:20px;;margin-top:30px;"></a><br>
     <a href="ClientSignIn.php"><input type="button" name="client" class="btn btn-info" value="Client" style="width:160px;"> </a>
    </div>
	</div>
	</div>
  <footer>


  			<div class="row" style="background-color:black;">
  				<div class="col-sm-6 col-md-4">
  					<div class="wow fadeInDown" data-wow-delay="0.1s">
  					<div class="widget">
  						<h2>About Us</h2>
  						<p>
  						We provide service of window cleaning
  						</p>
  					</div>
  					</div>
  					<div class="wow fadeInDown" data-wow-delay="0.1s">
  					<div class="widget">
  						<h4>Online Features</h4>
  						<ul>
  							<li><a href="#">You Can Make Account</a></li>
  							<li><a href="#">Check Details</a></li>
  							<li><a href="#">Online Order</a></li>
  							<li><a href="#">Online Payment</a></li>
  						</ul>
  					</div>
  					</div>
  				</div>
  				<div class="col-sm-6 col-md-4">
  					<div class="wow fadeInDown" data-wow-delay="0.1s">
  					<div class="widget">
  						<h2>Address</h2>
  						<p>
  						Muhammdi Town PAF Road
  						</p>
              <p>
  					  Street No 2
  						</p>
  						<ul>
  							<li>
  								<span class="fa-stack fa-lg">
  									<i class="fa fa-circle fa-stack-2x"></i>
  									<i class="fa fa-calendar-o fa-stack-1x fa-inverse"></i>
  								</span>Mianwali
  							</li>
  							<li>
  								<span class="fa-stack fa-lg">
  									<i class="fa fa-circle fa-stack-2x"></i>
  									<i class="fa fa-phone fa-stack-1x fa-inverse"></i>
  								</span> +62 0888 904 711
  							</li>
  							<li>
  								<span class="fa-stack fa-lg">
  									<i class="fa fa-circle fa-stack-2x"></i>
  									<i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i>
  								</span>rapidclean.com
  							</li>

  						</ul>
  					</div>
  					</div>
  				</div>
  				<div class="col-sm-6 col-md-4">
  					<div class="wow fadeInDown" data-wow-delay="0.1s">
  					<div class="widget">
  						<h2>Download Our App</h2>
  						<p><img src="images/googleplaystor.png" style="width:300px;float:left;margin-left:-20px;"></p>

  					</div>
  					</div>
