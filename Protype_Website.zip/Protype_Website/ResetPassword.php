<html>
<head>
<title>
Reset Password
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
#success_message{ display: none;}
body{
    background-image: url("images/9.jpg");

}
html{
  background-image: url(images/9.jpg);
}

</style>
<body>
  <div class="row" style="background-color:black;height:100px;text-align:center">
    <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;margin-top:-50px;"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
  </div>
  <div class="button text-center">



    <div style="height:350px;width:350px;margin-left:500px;">
	 <img src="images/gate.png" style="width:100px;height:100px;"></img>
     <br>

<form action=" " method="post"  id="contact_form"  >
<fieldset>
<legend style="color:white;">Reset Password!</legend>
<!--password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="password" placeholder="Type New Password" class="form-control" style="border-radius:10px;"  type="password">
    </div>
  </div>
</div><br><br>
<!--retype password-->
<div class="form-group" style="margin-left:60px;">

  <div class="col-md-10 inputGroupContainer">
  <div class="input-group">

  <input  name="re-password" placeholder="Re-type New Password" class="form-control" style="border-radius:10px;"  type="password">
    </div>
  </div>
</div><br><br>
<!-- Success message -->
<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <button type="submit" class="btn btn-warning" ><a href="StartPage.php" style="text-decoration:none; color:white;">Submit</a> <span class="glyphicon glyphicon-send"></span></button>
  </div>
</div>

</fieldset>
</form>
</div>
    </div>

</div>
</div>




</body>
</html>
