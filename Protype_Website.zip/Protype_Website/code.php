<html>
<head>
<title>
code
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
#success_message{ display: none;}
body{
        background-image: url("images/9.jpg");

}
html{
  background-image: url(images/9.jpg);
}

</style>
<body>
  <div class="row" style="background-color:black;height:100px;text-align:center">
    <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;margin-top:-50px;"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
  </div>

   <div style="height:350px;width:350px;margin-left:500px;">
	 <img src="images/gate.png" style="width:100px;height:100px;margin-left:110px;"></img>
     <br>

<form action=" " method="post"  id="contact_form"  >
<fieldset>
<legend style="color:white;padding-left:100px;">Enter code!</legend>
<!--password-->
<div class="form-group">

  <div class="col-md-8 inputGroupContainer">
  <div class="input-group">

  <input  name="code" placeholder="Enter code" class="form-control" style="border-radius:10px;margin-left:50px;"  type="text">
    </div>
  </div>
</div><br><br>
<!-- Button -->
<div class="form-group">
  <label class="col-md-3"></label>
  <div class="col-md-3">
    <button type="submit"  class="btn btn-warning" ><a href="ResetPassword.php" style="text-decoration:none; color:white;">Submit</a> <span class="glyphicon glyphicon-send"></span></button>
   <br>
  </div>
</div>
</fieldset>
</form>
</div>




</body>
</html>
