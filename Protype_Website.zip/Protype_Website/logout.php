<?php
require 'connection.inc.php';
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
$user=$_SESSION['username'];

$sql="DELETE FROM `online` WHERE username='$user'";
if($conn->query($sql)){
session_destroy();
header("location:StartPage.php");
exit();
}

?>
