<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>
Payment
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
*{
margin:0px;
padding:0px;
}
	body{
    background-color:#a5b3cc;
}

    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>
<div class="container-fluid">
<div class="row" style="background-color:black;height:100px;">
  <div class="col-sm-4"><img src="images/dps.png" style="width:300px;float:left;height:95px;"></div>
  <div class="clearfix"></div>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
   
      <ul class="nav navbar-nav navbar-left">
        <li class="active"><a href="Payment.php">Payments</a></li>
        <li ><a href="schedule.php">Schedule</a></li>
	    <li><a href="order.php">Orders</a></li>
        <li ><a href="clientComplain.php">Complaints</a></li>
        <li><a href="messagesuser.php">Messages</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php"  style="margin-left:-60px;margin-top:14px;">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  
</nav>

<div class="container text-center" >
  <br><br>	
 <div class="container" style="background-color:black;width:400px;margin-bottom:50px;padding-bottom:100px;padding-top:50px;opacity:0.5;border-radius:50px">
 <div>
 <img src="images/gate.png" style="width:100px;height:100px;margin-top:-30px;"></img>
	 <br>
     <legend style="color:black;">Payment</legend>
       <button type="button" class="btn btn-info btn-lg" style="width:200px;text-align:center;"><a href="Onlinepay.php" style="text-decoration:none;color:white;">Online Payment</a></button><br><br><br>
      <button type="button" class="btn btn-info btn-lg" style="width:200px;text-align:center;"><a href="cashpay.php" style="text-decoration:none;color:white;"> Cash Payment </a></button> <br><br><br>
    </div>
</div>
</div>

</body>


</html>
