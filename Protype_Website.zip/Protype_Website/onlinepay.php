<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['submit'])) {
$amount=$_POST['amount'];
$date=$_POST['date'];
$credit=$_POST['credit'];
if(!empty($amount) && !empty($date) && !empty($credit)){
  $sql = "SELECT * FROM user_orders WHERE Name='$user' AND data='$date'";
  $result = mysqli_query($conn, $sql);
  if($result){
    $up=$sql = "UPDATE user_orders SET price='$amount', paydtails='P' WHERE Name='$user' AND data='$date' ";
    if ($conn->query($up) === TRUE) {
            echo "<script>alert('Succesfuly Paid')</script>";
    }
  }
  else {
    echo "<script>alert('Enter Valid Input')</script>";

  }

}
else {
  echo "<script>alert('Enter Valid Input')</script>";

}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>
Payment
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }


    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="Payment.php">Payments</a></li>
        <li ><a href="schedule.php">Schedule</a></li>
	    <li><a href="order.php">Orders</a></li>
        <li ><a href="clientComplain.php">Complaints</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>
<div class="background"style=" background-image: url(images/9.jpg); margin-top:-50px;height:391px;padding-top:40px;">
<div class="button text-center">
   <div style="height:350px;width:500px;margin-left:425px;">
	 <img src="images/gate.png" style="width:100px;height:100px;"></img>
	 <br>
     <legend style="color:black;">Payment</legend>
     <form  class="well form-horizontal" action=" " method="post"  id="contact_form" style="background-color:white;" >
   <fieldset>
   <legend>Enter Details of Payment </legend>
   <div class="form-group"  >
    <label class="col-md-4 control-label">Credit Card No</label>
     <div class="col-md-4 inputGroupContainer">
     <div class="input-group">
     <input  name="credit" placeholder="Credit Card No" class="form-control"  type="text">
       </div>
     </div>
   </div>

   <div class="form-group">
    <label class="col-md-4 control-label">Amount</label>
     <div class="col-md-4 inputGroupContainer">
     <div class="input-group">
     <input  name="amount"  placeholder="Amount" class="form-control"  type="text">
       </div>
     </div>
   </div>
   <div class="form-group">
    <label class="col-md-4 control-label">Date</label>
     <div class="col-md-4 inputGroupContainer">
     <div class="input-group">
     <input  name="date"  placeholder="Date of Order" class="form-control"  type="text">
       </div>
     </div>
   </div>
   <div class="form-group">

     <input type="submit" name="submit" class="btn btn-warning" value="Submit">

       </div>
     </div>
   </div>
   </div>

    </div>
</div>
</div>
</body>


</html>
