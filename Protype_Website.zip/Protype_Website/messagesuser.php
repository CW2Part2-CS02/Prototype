<?php
session_start();
if(!$_SESSION['username']){
header("location:StartPage.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dps";
$user=$_SESSION['username'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 ?>
<!DOCTYPE html>
<html>
<head>
<title>
Notification
</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</head>
<style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    html{
      background-image: url(images/9.jpg);
    }

    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }


  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Window Cleaning</h1>

  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="Payment.php">Payments</a></li>
        <li ><a href="schedule.php">Schedule</a></li>
	    <li><a href="order.php">Orders</a></li>
        <li><a href="clientComplain.php">Complaints</a></li>
         <li  class="active"><a href="messagesuser.php">Messages</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form  method="post" action="logout.php">
          <input type="submit"  value="Logout" name="logout">
        </form>
      </ul>
    </div>
  </div>
</nav>
<?php
$sql ="SELECT * FROM `messages` WHERE username='$user'" ;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
   while($row = $result->fetch_assoc()) {
     $msg=$row['content'];
     echo "<div class='button'style=' background-image: url(images/9.jpg); margin-top:-50px;height:391px;padding-top:40px;'>
     <div class='container'>
       <div class='row'>
         <div class='col-sm-10'>
         <div class='panel panel-primary'>
         <div class='panel-heading'>Message</div>
         <div class='panel-body'>$msg</div>
       <div class='panel-footer '>
         <form>
           <div class='form-group'>
          <button type='button' name='delete'class='btn btn-primary '>Delete</button>
         </div>
       </form>
         </div>
         </div>

         </div>
       </div></div><br></div><br>";
   }

   }
   else{
      echo "<h1 style='float:left;color:white;margin-left:500px'>No Messages online</h1>";
}


 ?>
</body>


</html>
